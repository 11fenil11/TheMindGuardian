import 'package:flutter/material.dart';

const kPrimaryColor = Color.fromRGBO(17, 0, 255, 1);
const kPrimaryLightColor = Color.fromRGBO(24, 22, 23, 1);
